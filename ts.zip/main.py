﻿from pyrogram import Client, filters
import threading
import schedule
import time

garants = {-1001763068823: "@HermesGarantBot",
           -1001266598286:"📝 Связь: @k0od00\n🎩 Гарант: @scrooge_garantbot",
           -1001446642090: "",
           -1001496961087: "",
           -1001332422950: "Связь:@k0od00\nГарант: @lolzteam_garant_bot" }


text = '''
**Кодер на Python - работаю.**

🌊 Парсеры
🌊 Чекеры
🌊 Боты для TG
🌊 Работа с БД и таблицами
🌊 Работа с текстовыми файлами
🌊 Работа с изображениями

__Разрабатываю в кротчайшие сроки - от 2-ух часов.
Код выдается с понятной инструкцией.__

Моя тема на форуме - https://lolz.guru/threads/3495573/


РАБОТА СТРОГО С ГАРАНТОМ.

'''

app = Client("my_account")

def mailing():
    for i in garants.keys():
        garant = garants[i]
        try:
            app.send_photo(chat_id = i, photo = "banner.jpg" , caption = text + garant)
            print(f'Удачно проспамил {i}')
        except Exception as e:
            try:
                    app.send_message(chat_id = i, text = text + garant)
                    print(f'Удачно проспамил {i}')
            except Exception as e:
                print(f'Неудача {i}')
                pass


schedule.every(30).minutes.do(mailing)

def timer():
    while 1:
        schedule.run_pending()
        time.sleep(1)

t = threading.Thread(target=timer, name="тест")
t.start()

app.run();

